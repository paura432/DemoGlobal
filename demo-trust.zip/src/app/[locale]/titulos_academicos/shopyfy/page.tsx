'use client';

import React, { useMemo, useState, useEffect } from 'react';
import Image from 'next/image';
import { QRCodeCanvas } from 'qrcode.react';
import { useRouter, usePathname } from 'next/navigation';


type DiscountOption = {
  id: string;
  label: string;
  description: string;
  available?: boolean;
};

type TranslationSet = {
  discount: {
    options: DiscountOption[];
    applied: string;
    percentage: string;
  };
  verification: {
    steps: string[];
    error: string;
    studentVerified: string;
    discountApplied: string;
    applyDiscount: string;
    modalTitle: string;
    close: string;
    generating: string;
    instructions: string[];
    autoVerifying: string;
    verifying: string;
  };
  summary: {
    discounts: string;
    studentDiscount: string;
  };
};

/* =========================
   Config / Mock de producto
   ========================= */
const apiBase = process.env.NEXT_PUBLIC_VCS_API_URL || 'http://localhost:8085';

const ITEM = {
  id: '1',
  brand: 'New Look',
  title: {
    es: 'PANELLED - Chaqueta vaquera - azul',
    en: 'PANELLED - Denim jacket - blue'
  },
  price: 59.99,
  color: {
    es: 'azul',
    en: 'blue'
  },
  size: '36',
  image: '/titulos_academicos/chaqueta.jpg',
  seller: 'Shopyline Europe',
  qty: 1,
};

/* =========================
   Traducciones
   ========================= */
const TRANSLATIONS = {
  es: {
    cart: {
      title: "Tu cesta",
      items: "artículo",
      shipping: "Envío por parte de",
      deliveryDate: "Jue., 18.09 - Vie., 19.09",
      color: "Color",
      size: "Talla",
      saleThrough: "Venta a través de",
      moveToFavorites: "Mover a favoritos",
      reminder: "Recuerda: no podemos reservar los artículos en tu cesta.",
      quantity: "Cantidad"
    },
    summary: {
      subtotal: "Subtotal",
      studentDiscount: "Descuento estudiante",
      shipping: "Envío",
      total: "Total",
      vatIncluded: "IVA incluido",
      buy: "Comprar",
      returnToDemo: "Volver a demo",
      discounts: "Descuentos"
    },
    discount: {
      applied: "Descuento aplicado",
      percentage: "de descuento",
      options: [
        {
          id: 'verifiable-credential',
          label: 'Credencial verificable de estudiante',
          description: 'Descuento del 10%'
        },
        {
          id: 'student-card',
          label: 'Carnet estudiante',
          description: 'Descuento del 15%'
        }
      ]
    },
    verification: {
      modalTitle: "Verificar credencial",
      generating: "Generando QR…",
      instructions: ["Abre tu wallet", "Escanea el QR y comparte tu credencial"],
      autoVerifying: "Verificando automáticamente…",
      verifying: "Verificando",
      steps: [
        'Verificando credencial',
        'Validando expiración',
        'Confirmando validez',
        'Autenticando'
      ],
      studentVerified: "Estudiante verificado",
      discountApplied: "Descuento aplicado",
      applyDiscount: "Aplicar descuento",
      error: "Error de verificación",
      close: "Cerrar"
    }
  },
  en: {
    cart: {
      title: "Your cart",
      items: "item",
      shipping: "Shipped by",
      deliveryDate: "Thu., Sep 18 - Fri., Sep 19",
      color: "Color",
      size: "Size",
      saleThrough: "Sold by",
      moveToFavorites: "Move to favorites",
      reminder: "Remember: we cannot reserve items in your cart.",
      quantity: "Quantity"
    },
    summary: {
      subtotal: "Subtotal",
      studentDiscount: "Student discount",
      shipping: "Shipping",
      total: "Total",
      vatIncluded: "VAT included",
      buy: "Buy",
      returnToDemo: "Return to demo",
      discounts: "Discounts"
    },
    discount: {
      applied: "Discount applied",
      percentage: "discount",
      options: [
        {
          id: 'verifiable-credential',
          label: 'Student verifiable credential',
          description: '10% discount'
        },
        {
          id: 'student-card',
          label: 'Student card',
          description: '15% discount'
        }
      ]
    },
    verification: {
      modalTitle: "Verify credential",
      generating: "Generating QR…",
      instructions: ["Open your wallet", "Scan the QR and share your credential"],
      autoVerifying: "Verifying automatically…",
      verifying: "Verifying",
      steps: [
        'Verifying credential',
        'Validating expiration',
        'Confirming validity',
        'Authenticating'
      ],
      studentVerified: "Verified student",
      discountApplied: "Discount applied",
      applyDiscount: "Apply discount",
      error: "Verification error",
      close: "Close"
    }
  }
};

/* =========================
   Iconos
   ========================= */
function PersonIcon({ className = 'w-3 h-3 text-[#414B61]' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" className={className} fill="none">
      <circle cx="12" cy="8" r="3.25" stroke="currentColor" strokeWidth="1.5" />
      <path d="M5 19.25c.8-3.2 3.7-5 7-5s6.2 1.8 7 5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}

function CheckCircle({ className = 'w-3 h-3' }: { className?: string }) {
  return (
    <svg viewBox="0 0 20 20" className={className} aria-hidden="true">
      <circle cx="10" cy="10" r="10" fill="#22c55e" />
      <path d="M14.2 7.6 9 12.8 6.6 10.3" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function PendingCircle({ className = 'w-3 h-3' }: { className?: string }) {
  return (
    <svg viewBox="0 0 20 20" className={className} aria-hidden="true">
      <circle cx="10" cy="10" r="7.75" fill="none" stroke="#9ca3af" strokeWidth="1.5" />
    </svg>
  );
}

function IconCheck({ className = 'w-3 h-3' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M20 6 9 17l-5-5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

/* =========================
   Selector de cantidad
   ========================= */
function QtySelect({
  value,
  onChange,
  label
}: {
  value: number;
  onChange: (v: number) => void;
  label: string;
}) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button
        className="w-12 h-7 border rounded flex items-center justify-between px-1.5 text-xs"
        onClick={() => setOpen((o) => !o)}
        aria-label={label}
        type="button"
      >
        {value}
        <span>▾</span>
      </button>
      {open && (
        <div className="absolute z-10 bg-white border rounded mt-1 w-full text-xs">
          {[1, 2, 3, 4, 5].map((q) => (
            <button
              key={q}
              onClick={() => {
                onChange(q);
                setOpen(false);
              }}
              className={`w-full text-left px-1.5 py-1 hover:bg-gray-100 ${
                q === value ? 'font-semibold' : ''
              }`}
            >
              {q}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/* =========================
   Estado de credencial
   ========================= */
type StudentState = {
  verified: boolean;
  discountPercent: number;
  name?: string;
  exp?: string;
  uiLabel?: string;
};

function useStudentCred() {
  const [st, setSt] = useState<StudentState>({
    verified: false,
    discountPercent: 0,
  });

  return { st, setSt };
}

/* =========================
   Modal compacto
   ========================= */
function Modal({
  open,
  onClose,
  title,
  children,
  closeText
}: {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: React.ReactNode;
  closeText: string;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 grid place-items-center p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative bg-white rounded-xl shadow-lg w-full max-w-sm max-h-[85vh]">
        <div className="sticky top-0 bg-white border-b px-4 py-3 flex items-center justify-between">
          <h3 className="text-sm font-semibold">{title}</h3>
          <button onClick={onClose} aria-label={closeText} className="text-lg">✕</button>
        </div>
        <div className="p-4">
          {children}
        </div>
      </div>
    </div>
  );
}

/* =========================
   Dropdown compacto
   ========================= */
type Phase = 'loading' | 'qr' | 'verifying' | 'ready' | 'error';

function DiscountDropdown({
  current,
  onVerified,
  t
}: {
  current: StudentState;
  onVerified: (s: StudentState) => void;
  t: TranslationSet;
}) {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);

  const [phase, setPhase] = useState<Phase>('loading');
  const [qrLink, setQrLink] = useState('');
  const [sessionID, setSessionID] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [pendingResult, setPendingResult] = useState<StudentState | null>(null);

  const [activeStep, setActiveStep] = useState(0);
  const stepsDone = Math.min(activeStep, t.verification.steps.length);
  const pct = Math.round((stepsDone / t.verification.steps.length) * 100);

  const START_ENDPOINT = `${apiBase}/api/v1/verifier-back/procivis`;
  const STATUS_ENDPOINT = (sid: string) => `${apiBase}/api/v1/verifier-status/procivis/${sid}`;

  const discountOptions = t.discount.options.map((opt: DiscountOption) => ({
    ...opt,
    available: opt.id === 'verifiable-credential'
  }));

  const handleOptionClick = (optionId: string) => {
    setDropdownOpen(false);
    if (optionId === 'verifiable-credential') {
      startVerification();
    }
  };

  const startVerification = async () => {
    setModalOpen(true);
    setPhase('loading');
    setErrorMsg(null);
    setActiveStep(0);

    try {
      const res = await fetch(START_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ schema: 'estudiante' }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = await res.json();
      const data = json?.data ?? json;

      const link = data?.appUrl as string | undefined;
      const sid = data?.sessionID as string | undefined;

      if (!link || !sid) throw new Error('Respuesta incompleta');

      setQrLink(link);
      setSessionID(sid);
      setPhase('qr');
    } catch (e: unknown) {
      if (e instanceof Error) {
        setErrorMsg(e.message);
      } else {
        setErrorMsg('Error de conexión');
      }
      setPhase('error');
    }
    
  };

  // Polling simplificado
  useEffect(() => {
    if (!modalOpen || !sessionID) return;

    const id = setInterval(async () => {
      try {
        const res = await fetch(STATUS_ENDPOINT(sessionID));
        if (!res.ok) return;
        const json = await res.json();
        const data = json?.data ?? json;
        const status = data?.status as string | undefined;

        if (status === 'success' || status === 'verified') {
          setPendingResult({
            verified: true,
            discountPercent: 10,
            name: t.verification.studentVerified,
            uiLabel: t.verification.discountApplied,
          });

          setPhase('verifying');
          setActiveStep(0);

          const timers: ReturnType<typeof setTimeout>[] = [];
          t.verification.steps.forEach((_, i: number) => {
            timers.push(setTimeout(() => setActiveStep(i + 1), 900 * (i + 1)));
          });
          timers.push(setTimeout(() => setPhase('ready'), 900 * (t.verification.steps.length + 1)));
          clearInterval(id);
        }

        if (status === 'error' || status === 'rejected' || status === 'expired') {
          setPhase('error');
          setErrorMsg(t.verification.error);
          clearInterval(id);
        }
      } catch {}
    }, 1500);

    return () => clearInterval(id);
  }, [modalOpen, sessionID, t]);

  const applyAndClose = () => {
    const base: StudentState = {
      verified: true,
      discountPercent: 10,
      name: t.verification.studentVerified,
      uiLabel: t.verification.discountApplied,
    };
    onVerified(base);
    setModalOpen(false);
  };

  return (
    <>
      {current.verified ? (
        <div className="mt-2 p-2 rounded border bg-green-50 text-xs border-green-200">
          <div className="font-semibold text-green-700">{t.discount.applied} ✓</div>
          <div className="text-green-600">{current.discountPercent}% {t.discount.percentage}</div>
        </div>
      ) : (
        <div className="mt-2 relative">
          <button
            onClick={() => setDropdownOpen(!dropdownOpen)}
            className="w-full h-8 rounded-full text-xs font-semibold
                       border border-indigo-600 text-indigo-600
                       hover:bg-indigo-600 hover:text-white transition
                       flex items-center justify-center gap-1"
            type="button"
          >
            {t.summary.discounts}
          </button>

          {dropdownOpen && (
            <div className="absolute top-full left-0 right-0 mt-1 bg-white border rounded shadow-lg z-20 max-h-32 overflow-y-auto">
              {discountOptions.map((option: DiscountOption) => (
                <button
                  key={option.id}
                  onClick={() => handleOptionClick(option.id)}
                  disabled={!option.available}
                  className={`w-full text-left px-3 py-2 text-xs hover:bg-gray-50 
                    ${!option.available ? 'opacity-50 cursor-not-allowed' : ''}
                    border-b last:border-b-0`}
                >
                  <div className="font-semibold">{option.label}</div>
                  <div className="text-[#414B61]">{option.description}</div>
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      <Modal 
        open={modalOpen} 
        onClose={() => setModalOpen(false)} 
        title={t.verification.modalTitle}
        closeText={t.verification.close}
      >
        {phase === 'loading' && (
          <div className="text-sm text-[#414B61]">{t.verification.generating}</div>
        )}

        {phase === 'qr' && (
          <div className="space-y-3">
            <div className="text-xs text-[#414B61]">
              {t.verification.instructions.map((inst: string, i: number) => (
                <div key={i}>{i + 1}. {inst}</div>
              ))}
            </div>
            <div className="flex justify-center p-2 bg-gray-50 rounded">
              <QRCodeCanvas value={qrLink} size={150} level="M" />
            </div>
            <div className="text-xs text-[#414B61] text-center">{t.verification.autoVerifying}</div>
          </div>
        )}

        {(phase === 'verifying' || phase === 'ready') && (
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <PersonIcon />
              <h4 className="text-sm font-semibold">{t.verification.verifying}</h4>
            </div>

            <div className="w-full h-1 bg-gray-200 rounded-full">
              <div
                className="h-full bg-green-500 rounded-full transition-all duration-300"
                style={{ width: `${pct}%` }}
              />
            </div>

            <ul className="space-y-1.5">
              {t.verification.steps.map((label: string, i: number) => {
                const done = i < activeStep;
                return (
                  <li key={i} className="flex items-center gap-2">
                    {done ? <CheckCircle /> : <PendingCircle />}
                    <span className={`text-xs ${done ? 'text-[#414B61]' : 'text-[#414B61]'}`}>{label}</span>
                  </li>
                );
              })}
            </ul>

            {pendingResult && (
              <div className="text-xs text-[#414B61] text-center mt-2">
                <div className="font-semibold">{pendingResult.name}</div>
                <div>{pendingResult.uiLabel} ({pendingResult.discountPercent}%)</div>
              </div>
            )}

            {phase === 'ready' && (
              <button
                onClick={applyAndClose}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded text-sm font-medium transition"
                type="button"
              >
                {t.verification.applyDiscount}
              </button>
            )}
          </div>
        )}

        {phase === 'error' && (
          <div className="text-sm text-red-600 text-center">{errorMsg || t.verification.error}</div>
        )}
      </Modal>
    </>
  );
}

/* =========================
   Página principal compacta
   ========================= */
export default function CartPage() {
  const router = useRouter();
  const pathname = usePathname();
  const locale = (pathname.split('/')[1] || 'es') as 'es' | 'en';
  const t = TRANSLATIONS[locale];

  const [qty, setQty] = useState<number>(ITEM.qty);
  const { st: student, setSt } = useStudentCred();

  const subtotal = useMemo(() => +(ITEM.price * qty).toFixed(2), [qty]);
  const discountAmount = useMemo(
    () => (student.verified ? +((ITEM.price * qty) * (student.discountPercent / 100)).toFixed(2) : 0),
    [qty, student]
  );
  const total = useMemo(() => +(subtotal - discountAmount).toFixed(2), [subtotal, discountAmount]);

  const goDemo = () => router.push(`/${locale}/`);

  const ctaLabel = student.verified ? t.summary.returnToDemo : t.summary.buy;
  const ctaClasses = `w-full h-9 rounded text-sm font-semibold flex items-center justify-center gap-1.5 transition
    ${student.verified ? 'bg-green-600 hover:bg-green-700 text-white' : 'bg-black hover:opacity-90 text-white'}`;

  return (
    <div className="bg-white text-[#414B61] flex flex-col">
      <main className="flex-1 max-w-[1100px] mx-auto px-4 grid grid-cols-1 lg:grid-cols-[1fr_340px] gap-6 py-6">
        
        <section>
          <h1 className="text-2xl font-semibold mb-5">{t.cart.title} (1 {t.cart.items})</h1>
  
          <div className="flex items-center gap-2 text-sm text-[#414B61] mb-4">
            <span className="inline-flex items-center justify-center w-5 h-5 rounded border">📦</span>
            <span>
              {t.cart.shipping} <span className="font-semibold">Shopyline</span>
              <span className="block text-[#414B61]">{t.cart.deliveryDate}</span>
            </span>
          </div>
  
          <div className="flex gap-3">
            <div className="w-20 h-24 relative overflow-hidden rounded">
              <Image width={40} height={40} src={ITEM.image} alt={ITEM.title[locale]} className="w-full h-full object-cover" />
            </div>
            <div className="flex-1">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="text-xs text-[#414B61]">{ITEM.brand}</div>
                  <div className="font-semibold text-sm">{ITEM.title[locale]}</div>
                  <div className="mt-1 text-xs text-[#414B61]">{ITEM.price.toFixed(2)} €</div>
                  <div className="mt-1 text-xs text-[#414B61]">{t.cart.color}: {ITEM.color[locale]}</div>
                  <div className="text-xs text-[#414B61]">{t.cart.size}: {ITEM.size}</div>
                  <div className="mt-1 text-xs">
                    {t.cart.saleThrough} <a className="underline font-semibold" href="#">{ITEM.seller}</a>
                  </div>
                </div>
  
                <div className="flex items-start gap-3">
                  <QtySelect value={qty} onChange={setQty} label={t.cart.quantity} />
                  <button aria-label="Delete item" className="h-9 w-9 grid place-items-center">✕</button>
                </div>
              </div>
              <button className="mt-2 text-violet-600 text-xs hover:underline">{t.cart.moveToFavorites}</button>
            </div>
          </div>
  
          <p className="mt-6 text-xs text-[#414B61]">❗ {t.cart.reminder}</p>
        </section>
      <aside className="bg-gray-100 p-4 rounded self-start" style={{maxHeight: '70vh'}}>
        <div className="flex items-center justify-between text-sm py-1.5">
          <span>{t.summary.subtotal}</span>
          <span>{subtotal.toFixed(2)} €</span>
        </div>

        {student.verified && (
          <div className="flex items-center justify-between text-sm py-1.5 text-green-700">
            <span>{t.summary.studentDiscount} ({student.discountPercent}%)</span>
            <span>-{discountAmount.toFixed(2)} €</span>
          </div>
        )}

        <div className="flex items-center justify-between text-sm py-1.5 border-b">
          <span>{t.summary.shipping}</span>
          <span>0,00 €</span>
        </div>

        <div className="flex items-center justify-between font-semibold text-base py-3">
          <span>{t.summary.total} <span className="text-[#414B61] text-xs">{t.summary.vatIncluded}</span></span>
          <span className="text-[18px]">{total.toFixed(2)} €</span>
        </div>

        <button
          onClick={goDemo}
          className={`${ctaClasses} ${!student.verified ? 'opacity-50 cursor-not-allowed' : ''}`}
          disabled={!student.verified}
        >
          {student.verified && <IconCheck className="w-4 h-4" />} {ctaLabel}
        </button>

        <DiscountDropdown current={student} onVerified={setSt} t={t} />
      </aside>
    </main>
  </div>
  );
}